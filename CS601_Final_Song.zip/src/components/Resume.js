import React from "react";

function Resume() {
  return (
    <section>
      <h2>Education</h2>
      <p>Boston University - Master of Science in Computer Science</p>
    </section>
  );
}

export default Resume;
