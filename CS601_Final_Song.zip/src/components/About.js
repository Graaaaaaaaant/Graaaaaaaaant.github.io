import React from "react";

function About() {
  return (
    <section>
      <h2>Biography</h2>
      <p>I am Hengyi Song, pursuing Master's degree in Computer Science from Boston University.</p>
    </section>
  );
}

export default About;
