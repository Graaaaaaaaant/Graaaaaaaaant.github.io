import React from "react";

function Home() {
  return (
    <section>
      <h2>Welcome to My Portfolio</h2>
      <p>Explore my portfolio to learn more about me and my work!</p>
    </section>
  );
}

export default Home;
